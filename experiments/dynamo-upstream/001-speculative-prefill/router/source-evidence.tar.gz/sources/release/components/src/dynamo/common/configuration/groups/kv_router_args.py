# SPDX-FileCopyrightText: Copyright (c) 2025-2026 NVIDIA CORPORATION & AFFILIATES. All rights reserved.
# SPDX-License-Identifier: Apache-2.0

"""Shared KV router configuration ArgGroup.

Defines the shared KvRouterConfig parameters once so that both
``dynamo.frontend`` and ``dynamo.router`` can reuse them without duplication.
Field names on ``KvRouterConfigBase`` match the ``KvRouterConfig`` Python
constructor kwargs 1:1, so ``kv_router_kwargs()`` returns a dict that can be
unpacked directly into ``KvRouterConfig(**config.kv_router_kwargs())``.
"""

import argparse
import json
import logging
import os
import warnings
from typing import Any, Optional

from dynamo.common.configuration.arg_group import ArgGroup
from dynamo.common.configuration.config_base import ConfigBase
from dynamo.common.configuration.utils import (
    add_argument,
    add_negatable_bool_argument,
    nullable_float,
)

logger = logging.getLogger(__name__)

# Authoritative field list — used by kv_router_kwargs() to extract values.
_KV_ROUTER_FIELDS: tuple[str, ...] = (
    "overlap_score_weight",
    "overlap_score_credit",
    "overlap_score_credit_decay",
    "prefill_load_scale",
    "decode_active_request_weight",
    "host_cache_hit_weight",
    "disk_cache_hit_weight",
    "router_temperature",
    "use_kv_events",
    "router_replica_sync",
    "router_track_active_blocks",
    "router_track_output_blocks",
    "router_assume_kv_reuse",
    "router_track_prefill_tokens",
    "router_tracking_hash",
    "router_tracking_key_file",
    "router_tracking_key_id",
    "router_prefill_load_model",
    "router_ttl_secs",
    "router_approximate_cache_policy",
    "router_queue_threshold",
    "router_policy_config",
    "router_prefill_policy",
    "router_decode_policy",
    "router_event_threads",
    "router_queue_policy",
    "use_remote_indexer",
    "serve_indexer",
    "shared_cache_multiplier",
    "shared_cache_type",
    "conditional_disagg_enabled",
    "conditional_disagg_policy",
    "conditional_disagg_eff_isl_threshold",
    "conditional_disagg_eff_isl_ratio_threshold",
    "conditional_disagg_prefill_busy_threshold",
    "conditional_disagg_decode_busy_threshold",
    "router_predicted_ttl_secs",
)

CONDITIONAL_DISAGG_POLICY_CHOICES: tuple[str, ...] = (
    "isl_bounding",
    "prefill_load",
    "isl_or_load",
)
LOAD_AWARE_CONDITIONAL_DISAGG_POLICIES: frozenset[str] = frozenset(
    {"prefill_load", "isl_or_load"}
)

_CONDITIONAL_DISAGG_CONFIG_FIELDS: dict[str, str] = {
    "policy": "conditional_disagg_policy",
    "eff_isl_threshold": "conditional_disagg_eff_isl_threshold",
    "eff_isl_ratio_threshold": "conditional_disagg_eff_isl_ratio_threshold",
    "prefill_busy_threshold": "conditional_disagg_prefill_busy_threshold",
    "decode_busy_threshold": "conditional_disagg_decode_busy_threshold",
}

_DEPRECATED_OVERLAP_WEIGHT_MESSAGE = (
    "router KV overlap score weight is deprecated; use "
    "--router-prefill-load-scale or DYN_ROUTER_PREFILL_LOAD_SCALE for equivalent behavior"
)
_LOAD_AWARE_KWARG_OVERRIDES = {
    "overlap_score_credit": 0.0,
    "use_kv_events": False,
    "router_track_active_blocks": True,
    "router_assume_kv_reuse": False,
    "router_track_prefill_tokens": True,
    "use_remote_indexer": False,
    "serve_indexer": False,
    "shared_cache_multiplier": 0.0,
    "shared_cache_type": "none",
    "router_predicted_ttl_secs": None,
}


class _DeprecatedOverlapScoreWeightAction(argparse.Action):
    def __call__(self, parser, namespace, values, option_string=None) -> None:
        warnings.warn(_DEPRECATED_OVERLAP_WEIGHT_MESSAGE, FutureWarning, stacklevel=2)
        setattr(namespace, self.dest, values)


def _deprecated_overlap_score_weight_from_env() -> Optional[tuple[str, float]]:
    for env_var in ("DYN_ROUTER_KV_OVERLAP_SCORE_WEIGHT", "DYN_OVERLAP_SCORE_WEIGHT"):
        if env_var in os.environ:
            return env_var, float(os.environ[env_var])
    return None


def _default_overlap_score_weight() -> Optional[float]:
    legacy = _deprecated_overlap_score_weight_from_env()
    if legacy is None:
        return None

    env_var, value = legacy
    warnings.warn(
        f"{env_var} is deprecated; use DYN_ROUTER_PREFILL_LOAD_SCALE",
        FutureWarning,
        stacklevel=3,
    )

    return value


def _default_prefill_load_scale() -> float:
    return 1.0


def _parse_conditional_disagg_config(value: str) -> dict[str, Any]:
    try:
        parsed = json.loads(value)
    except json.JSONDecodeError as exc:
        raise ValueError(
            "--router-conditional-disagg-config must be a JSON object"
        ) from exc
    if not isinstance(parsed, dict):
        raise ValueError("--router-conditional-disagg-config must be a JSON object")

    unknown = sorted(set(parsed) - set(_CONDITIONAL_DISAGG_CONFIG_FIELDS))
    if unknown:
        raise ValueError(
            "--router-conditional-disagg-config has unknown field(s): "
            + ", ".join(unknown)
        )
    if "policy" in parsed and not isinstance(parsed["policy"], str):
        raise ValueError("--router-conditional-disagg-config policy must be a string")
    if "eff_isl_threshold" in parsed and (
        not isinstance(parsed["eff_isl_threshold"], int)
        or isinstance(parsed["eff_isl_threshold"], bool)
    ):
        raise ValueError(
            "--router-conditional-disagg-config eff_isl_threshold must be an integer"
        )
    if "eff_isl_ratio_threshold" in parsed and (
        parsed["eff_isl_ratio_threshold"] is None
        or not isinstance(parsed["eff_isl_ratio_threshold"], (int, float))
        or isinstance(parsed["eff_isl_ratio_threshold"], bool)
    ):
        raise ValueError(
            "--router-conditional-disagg-config eff_isl_ratio_threshold must be a number"
        )
    for field in ("prefill_busy_threshold", "decode_busy_threshold"):
        if parsed.get(field) is None:
            continue
        if not isinstance(parsed[field], (int, float)) or isinstance(
            parsed[field], bool
        ):
            raise ValueError(
                f"--router-conditional-disagg-config {field} must be a number"
            )
    return parsed


def _conditional_disagg_config_arg(value: str) -> dict[str, Any]:
    try:
        return _parse_conditional_disagg_config(value)
    except ValueError as exc:
        raise argparse.ArgumentTypeError(str(exc)) from exc


class KvRouterConfigBase(ConfigBase):
    """Mixin carrying the shared KvRouterConfig fields."""

    overlap_score_weight: Optional[float] = None
    overlap_score_credit: float
    overlap_score_credit_decay: float
    prefill_load_scale: float
    decode_active_request_weight: float
    host_cache_hit_weight: float
    disk_cache_hit_weight: float
    router_temperature: float
    use_kv_events: bool
    router_replica_sync: bool
    router_track_active_blocks: bool
    router_track_output_blocks: bool
    router_assume_kv_reuse: bool
    router_track_prefill_tokens: bool
    router_tracking_hash: str = "public-xxh3-v1"
    router_tracking_key_file: Optional[str] = None
    router_tracking_key_id: Optional[str] = None
    router_prefill_load_model: str
    router_ttl_secs: float
    router_approximate_cache_policy: str = "ttl"
    router_queue_threshold: Optional[float]
    router_policy_config: Optional[str] = None
    router_prefill_policy: Optional[str] = None
    router_decode_policy: Optional[str] = None
    router_event_threads: int
    router_queue_policy: str
    use_remote_indexer: bool = False
    serve_indexer: bool = False
    shared_cache_multiplier: float = 0.0
    shared_cache_type: str = "none"
    conditional_disagg_enabled: bool = False
    conditional_disagg_config: Optional[dict[str, Any]] = None
    conditional_disagg_policy: str = "isl_bounding"
    conditional_disagg_eff_isl_threshold: int = 2048
    conditional_disagg_eff_isl_ratio_threshold: float = 0.7
    conditional_disagg_prefill_busy_threshold: Optional[float] = None
    conditional_disagg_decode_busy_threshold: Optional[float] = None
    router_predicted_ttl_secs: Optional[float] = None
    load_aware: bool = False

    def apply_load_aware_preset(self) -> None:
        if not self.load_aware:
            return

        for field, value in _LOAD_AWARE_KWARG_OVERRIDES.items():
            setattr(self, field, value)

    def apply_conditional_disagg_config(self) -> None:
        if (
            self.conditional_disagg_config is not None
            and not self.conditional_disagg_enabled
        ):
            raise ValueError(
                "--router-conditional-disagg-config requires --router-conditional-disagg"
            )

        if self.conditional_disagg_config is not None:
            for key, value in self.conditional_disagg_config.items():
                setattr(self, _CONDITIONAL_DISAGG_CONFIG_FIELDS[key], value)

        if not self.conditional_disagg_enabled:
            return
        if self.conditional_disagg_policy not in LOAD_AWARE_CONDITIONAL_DISAGG_POLICIES:
            return
        # Load-aware conditional-disagg policies need a prefill busy threshold.
        # If threshold is not user-provided via --router-conditional-disagg-config,
        # default to --router-queue-threshold when that flag is set.
        if self.conditional_disagg_prefill_busy_threshold is not None:
            return
        if self.router_queue_threshold is not None:
            self.conditional_disagg_prefill_busy_threshold = self.router_queue_threshold
            logger.info(
                "conditional_disagg prefill_busy_threshold defaults to "
                "--router-queue-threshold=%s",
                self.router_queue_threshold,
            )
        else:
            raise ValueError(
                f"conditional_disagg policy={self.conditional_disagg_policy!r} "
                "needs prefill_busy_threshold, but neither "
                "prefill_busy_threshold nor --router-queue-threshold is set"
            )

    def kv_router_kwargs(self) -> dict:
        """Return a dict suitable for ``KvRouterConfig(**kwargs)``."""
        self.apply_load_aware_preset()
        self.apply_conditional_disagg_config()
        return {f: getattr(self, f) for f in _KV_ROUTER_FIELDS}


class KvRouterArgGroup(ArgGroup):
    """CLI arguments for the shared KvRouterConfig parameters."""

    def add_arguments(self, parser) -> None:
        g = parser.add_argument_group("KV Router Options")

        add_negatable_bool_argument(
            g,
            flag_name="--load-aware",
            env_var="DYN_ROUTER_LOAD_AWARE",
            default=False,
            dest="load_aware",
            help=(
                "KV Router: Enable load-aware routing without cache-reuse signals. "
                "On the frontend, this implies --router-mode kv. "
                "This preset sets overlap_score_credit=0, disables KV events and "
                "KV-reuse assumptions, enables active-block "
                "and prefill-token load tracking, and disables remote/shared cache indexers."
            ),
        )
        add_argument(
            g,
            flag_name="--router-kv-overlap-score-credit",
            env_var="DYN_ROUTER_KV_OVERLAP_SCORE_CREDIT",
            default=1.0,
            help=(
                "KV Router: Credit multiplier for device-local prefix overlap. "
                "Must be finite and non-negative; values above 1.0 give device "
                "overlap extra credit, with adjusted prefill cost clamped at zero."
            ),
            arg_type=float,
            dest="overlap_score_credit",
        )
        add_argument(
            g,
            flag_name="--router-kv-overlap-score-credit-decay",
            env_var="DYN_ROUTER_KV_OVERLAP_SCORE_CREDIT_DECAY",
            default=0.0,
            help=(
                "KV Router: Decay rate for device-local overlap credit as active "
                "prefill load rises above the least-loaded eligible worker. "
                "0 disables decay; 1 halves credit at one request-equivalent "
                "of excess active prefill load."
            ),
            arg_type=float,
            dest="overlap_score_credit_decay",
        )
        g.add_argument(
            "--router-kv-overlap-score-weight",
            "--kv-overlap-score-weight",
            dest="overlap_score_weight",
            type=float,
            action=_DeprecatedOverlapScoreWeightAction,
            default=_default_overlap_score_weight(),
            help=argparse.SUPPRESS,
        )
        add_argument(
            g,
            flag_name="--router-prefill-load-scale",
            env_var="DYN_ROUTER_PREFILL_LOAD_SCALE",
            default=_default_prefill_load_scale(),
            help=(
                "KV Router: Scale applied to adjusted prompt-side prefill load after "
                "overlap and lower-tier cache-hit credits are subtracted."
            ),
            arg_type=float,
            dest="prefill_load_scale",
        )
        add_argument(
            g,
            flag_name="--router-decode-active-request-weight",
            env_var="DYN_ROUTER_DECODE_ACTIVE_REQUEST_WEIGHT",
            default=0.0,
            help=(
                "[EXPERIMENTAL] KV Router: Block-equivalent decode cost added for "
                "each active request on a candidate worker. Use this to balance "
                "decode batch size when step latency depends more on request count "
                "than resident KV footprint. Must be finite and non-negative."
            ),
            arg_type=float,
            dest="decode_active_request_weight",
        )
        add_argument(
            g,
            flag_name="--router-host-cache-hit-weight",
            env_var="DYN_ROUTER_HOST_CACHE_HIT_WEIGHT",
            default=0.75,
            help=(
                "KV Router: Credit multiplier for host-pinned (CPU offload) prefix overlap. "
                "Range: 0.0 to 1.0; higher values more strongly prefer workers holding the "
                "prefix in CPU-tier KV cache. Symmetric to --router-kv-overlap-score-credit "
                "but applied to host_pinned tier overlap."
            ),
            arg_type=float,
            dest="host_cache_hit_weight",
        )
        add_argument(
            g,
            flag_name="--router-disk-cache-hit-weight",
            env_var="DYN_ROUTER_DISK_CACHE_HIT_WEIGHT",
            default=0.25,
            help=(
                "KV Router: Credit multiplier for disk/lower-tier (e.g. NVMe-backed) prefix overlap. "
                "Range: 0.0 to 1.0. Same semantics as --router-host-cache-hit-weight applied to "
                "the disk tier."
            ),
            arg_type=float,
            dest="disk_cache_hit_weight",
        )
        add_argument(
            g,
            flag_name="--router-temperature",
            env_var="DYN_ROUTER_TEMPERATURE",
            default=0.0,
            help=(
                "KV Router: Temperature for normalized worker sampling via softmax. "
                "Higher values promote more randomness, and 0 falls back to deterministic."
            ),
            arg_type=float,
        )
        add_negatable_bool_argument(
            g,
            flag_name="--router-kv-events",
            env_var="DYN_ROUTER_USE_KV_EVENTS",
            default=True,
            help=(
                "KV Router: Enable/disable KV events. Use --router-kv-events to enable "
                "(default, router receives cache state events from workers) or --no-router-kv-events "
                "to disable (router predicts cache state based on routing decisions)."
            ),
            dest="use_kv_events",
            obsolete_flag="--kv-events",
        )
        add_negatable_bool_argument(
            g,
            flag_name="--router-replica-sync",
            env_var="DYN_ROUTER_REPLICA_SYNC",
            default=False,
            help=(
                "KV Router: Enable best-effort active-sequence synchronization through "
                "the Runtime event plane."
            ),
        )
        add_negatable_bool_argument(
            g,
            flag_name="--router-track-active-blocks",
            env_var="DYN_ROUTER_TRACK_ACTIVE_BLOCKS",
            default=True,
            dest="router_track_active_blocks",
            help=(
                "KV Router: Track active blocks (blocks being used for ongoing generation). "
                "By default, active blocks are tracked for load balancing."
            ),
            obsolete_flag="--track-active-blocks",
        )
        add_negatable_bool_argument(
            g,
            flag_name="--router-track-output-blocks",
            env_var="DYN_ROUTER_TRACK_OUTPUT_BLOCKS",
            default=False,
            dest="router_track_output_blocks",
            help=(
                "KV Router: Track output blocks during generation. When enabled, the router adds "
                "placeholder blocks as tokens are generated. With expected output sequence length, "
                "fractional decay applies to output blocks and the structurally exclusive prompt "
                "suffix; shared prompt blocks retain full weight."
            ),
            obsolete_flag="--track-output-blocks",
        )
        add_negatable_bool_argument(
            g,
            flag_name="--router-assume-kv-reuse",
            env_var="DYN_ROUTER_ASSUME_KV_REUSE",
            default=True,
            dest="router_assume_kv_reuse",
            help=(
                "KV Router: When tracking active blocks, assume KV cache reuse. "
                "Use --no-router-assume-kv-reuse to generate random hashes instead "
                "(when KV cache reuse is not expected)."
            ),
            obsolete_flag="--assume-kv-reuse",
        )
        add_negatable_bool_argument(
            g,
            flag_name="--router-track-prefill-tokens",
            env_var="DYN_ROUTER_TRACK_PREFILL_TOKENS",
            default=True,
            dest="router_track_prefill_tokens",
            help=(
                "KV Router: Include prompt-side prefill tokens in active load accounting. "
                "Use --no-router-track-prefill-tokens to ignore prompt tokens in router "
                "prefill-token load, queue pressure, and active_prefill_tokens metrics."
            ),
        )
        add_argument(
            g,
            flag_name="--router-tracking-hash",
            env_var="DYN_ROUTER_TRACKING_HASH",
            default="public-xxh3-v1",
            choices=["public-xxh3-v1", "keyed-xxh3-v1"],
            help="KV Router: Hash function for router-derived active-sequence identities.",
        )
        add_argument(
            g,
            flag_name="--router-tracking-key-file",
            env_var="DYN_ROUTER_TRACKING_KEY_FILE",
            default=None,
            help="KV Router: File containing the 32-byte provider tracking key.",
        )
        add_argument(
            g,
            flag_name="--router-tracking-key-id",
            env_var="DYN_ROUTER_TRACKING_KEY_ID",
            default=None,
            help="KV Router: Provider-managed tracking-key epoch identifier.",
        )
        add_argument(
            g,
            flag_name="--router-prefill-load-model",
            env_var="DYN_ROUTER_PREFILL_LOAD_MODEL",
            default="none",
            choices=["none", "aic"],
            help=(
                "[EXPERIMENTAL] KV Router: Prompt-side prefill load model. "
                "'none' keeps static prompt load accounting. "
                "'aic' decays the oldest active prefill request using AIC-predicted duration."
            ),
        )
        add_argument(
            g,
            flag_name="--router-ttl-secs",
            env_var="DYN_ROUTER_TTL_SECS",
            default=120.0,
            help=(
                "KV Router: Time-to-live in seconds for blocks when KV events are disabled. "
                "Only used when --no-router-kv-events is set."
            ),
            arg_type=float,
        )
        add_argument(
            g,
            flag_name="--router-approximate-cache-policy",
            env_var="DYN_ROUTER_APPROXIMATE_CACHE_POLICY",
            default="ttl",
            choices=["ttl", "lru"],
            help=(
                "[EXPERIMENTAL] KV Router: Retention policy for the local primary "
                "approximate indexer used with --no-router-kv-events. 'ttl' keeps "
                "the existing time-based behavior; 'lru' uses each worker rank's "
                "advertised KV capacity. Side indexers remain TTL-only."
            ),
        )
        add_argument(
            g,
            flag_name="--router-queue-threshold",
            env_var="DYN_ROUTER_QUEUE_THRESHOLD",
            default=None,
            help=(
                "KV Router: Queue threshold fraction for prefill token capacity. "
                "Requests are queued if all workers exceed this fraction of "
                "max_num_batched_tokens. Must be >= 0. Use 0.0 for maximum "
                "queueing sensitivity (queue once every eligible worker has active "
                "prefill load). "
                "Unset by default; setting a numeric value enables router queueing. "
                "Note (SGLang backend): when --max-prefill-tokens is not set, MDC's "
                "max_num_batched_tokens falls back to max_total_num_tokens (the KV "
                "cache pool size), not the per-step prefill window, which inflates "
                "the threshold's effective denominator. Set --max-prefill-tokens "
                "explicitly for predictable semantics, or use a smaller threshold."
            ),
            arg_type=nullable_float,
        )
        add_argument(
            g,
            flag_name="--router-policy-config",
            env_var="DYN_ROUTER_POLICY_CONFIG",
            default=None,
            help=(
                "KV Router: Startup-only YAML configuration for policy-class queues "
                "and custom worker-selection instances. "
                "When omitted, router_queue_threshold and router_queue_policy define "
                "one synthetic policy class; queueing remains disabled unless "
                "router_queue_threshold is set."
            ),
            arg_type=str,
        )
        add_negatable_bool_argument(
            g,
            flag_name="--router-conditional-disagg",
            env_var="DYN_ROUTER_CONDITIONAL_DISAGG",
            default=False,
            help=(
                "[EXPERIMENTAL] KV Router: Enable conditional disaggregation. "
                "When enabled, the router may bypass the remote prefill step "
                "and route requests directly to a decode worker. The configured "
                "policy determines whether local prefill and decode is preferable "
                "for each request."
            ),
            dest="conditional_disagg_enabled",
        )
        add_argument(
            g,
            flag_name="--router-conditional-disagg-config",
            env_var="DYN_ROUTER_CONDITIONAL_DISAGG_CONFIG",
            default=None,
            help=(
                "[EXPERIMENTAL] KV Router: JSON object for conditional "
                "disaggregation policy settings. Supported fields: policy, "
                "eff_isl_threshold, eff_isl_ratio_threshold, "
                "prefill_busy_threshold, decode_busy_threshold."
            ),
            arg_type=_conditional_disagg_config_arg,
            dest="conditional_disagg_config",
            metavar="JSON",
        )
        add_argument(
            g,
            flag_name="--router-prefill-policy",
            env_var="DYN_ROUTER_PREFILL_POLICY",
            default=None,
            help=(
                "KV Router: Process-local named worker-selection instance for "
                "disaggregated prefill workers in this router process. "
                "Overrides worker_selection.prefill from --router-policy-config. "
                "Use 'default' for Dynamo's built-in worker selector."
            ),
            arg_type=str,
        )
        add_argument(
            g,
            flag_name="--router-decode-policy",
            env_var="DYN_ROUTER_DECODE_POLICY",
            default=None,
            help=(
                "KV Router: Process-local named worker-selection instance for decode "
                "workers in this router process. "
                "Overrides worker_selection.decode from --router-policy-config. "
                "Use 'default' for Dynamo's built-in worker selector."
            ),
            arg_type=str,
        )
        add_argument(
            g,
            flag_name="--router-event-threads",
            env_var="DYN_ROUTER_EVENT_THREADS",
            default=4,
            help=(
                "KV Router: Number of KV indexer worker threads. When > 1, uses a concurrent "
                "radix tree with a thread pool for higher throughput, including "
                "approximate routing when --no-router-kv-events is set."
            ),
            arg_type=int,
        )
        add_argument(
            g,
            flag_name="--router-queue-policy",
            env_var="DYN_ROUTER_QUEUE_POLICY",
            default="fcfs",
            help=(
                "KV Router: Scheduling policy for the router queue. "
                "'fcfs' (default): first-come first-served with priority bumps — optimizes tail TTFT. "
                "'wspt': weighted shortest processing time (Smith's rule) — optimizes average TTFT."
            ),
            arg_type=str,
            choices=["fcfs", "wspt"],
        )
        add_negatable_bool_argument(
            g,
            flag_name="--use-remote-indexer",
            env_var="DYN_USE_REMOTE_INDEXER",
            default=False,
            help=(
                "[EXPERIMENTAL] KV Router: Query a remote KV indexer served from the worker "
                "component via the request plane instead of maintaining a local radix tree."
            ),
            dest="use_remote_indexer",
        )
        add_argument(
            g,
            flag_name="--shared-cache-multiplier",
            env_var="DYN_SHARED_CACHE_MULTIPLIER",
            default=0.5,
            help=(
                "[EXPERIMENTAL] KV Router: Multiplier for shared cache hits (0.0-1.0). "
                "Blocks in the shared cache are less valuable than device-local blocks. "
                "E.g. 0.5 means each shared hit counts as half a device-local hit. "
                "Default 0.5."
            ),
            arg_type=float,
        )
        add_argument(
            g,
            flag_name="--shared-cache-type",
            env_var="DYN_SHARED_CACHE_TYPE",
            default="none",
            help=(
                "[EXPERIMENTAL] KV Router: Type of external shared KV cache to query. "
                "'none' (default): disabled. "
                "'hicache': query Mooncake master directly for SGLang L3 (HiCache) state "
                "using SGLang-compatible Mooncake key derivation."
            ),
            arg_type=str,
            choices=["none", "hicache"],
        )
        add_argument(
            g,
            flag_name="--router-predicted-ttl-secs",
            env_var="DYN_ROUTER_PREDICTED_TTL_SECS",
            default=None,
            help=(
                "KV Router: Enable predict-on-route with this TTL in seconds for entries "
                "in the local side indexer. Requires KV events; omit to disable. "
                "Independent of --router-ttl-secs, which covers pure approximate mode."
            ),
            arg_type=float,
        )
