import json, importlib.metadata, pathlib, psutil
root=pathlib.Path('/tmp/reedcode-dynamo')
pid=int((root/'backend.pid').read_text())
p=psutil.Process(pid)
data={'backend_pid':pid,'frontend_pid':int((root/'frontend.pid').read_text()),'processes':[{'pid':q.pid,'name':q.name(),'create_time':q.create_time(),'cmdline':q.cmdline()} for q in [p]+p.children(recursive=True)],'versions':{k:importlib.metadata.version(k) for k in ['vllm','ai-dynamo','torch']}}
print(json.dumps(data,indent=2))
