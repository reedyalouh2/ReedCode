#!/usr/bin/env bash
set -euo pipefail
cd /tmp/reedcode-dynamo
export DYN_REQUEST_TRACE=1
export DYN_REQUEST_TRACE_SINKS=file
export DYN_REQUEST_TRACE_FILE_FORMAT=jsonl
export DYN_REQUEST_TRACE_RECORDS=request_end,request_payload
export DYN_LOGGING_CONSOLE_FORMAT=jsonl
export DYN_EVENT_PLANE=zmq
export DYN_LOG=info
export HF_HOME=/tmp/reedcode-dynamo/hf
DYN_SYSTEM_PORT=8081 DYN_REQUEST_TRACE_FILE_PATH=/tmp/reedcode-dynamo/backend-trace.jsonl \
  nohup python3 -m dynamo.vllm \
  --model Qwen/Qwen3-8B --revision b968826d9c46dd6066d109eabc6255188de91218 \
  --discovery-backend file \
  --dtype bfloat16 --max-model-len 32768 --gpu-memory-utilization 0.80 \
  --enable-prefix-caching \
  --kv-events-config '{"enable_kv_cache_events":true,"publisher":"zmq","topic":"kv-events","endpoint":"tcp://*:5557"}' \
  --dyn-tool-call-parser hermes --dyn-reasoning-parser qwen3 \
  --dyn-default-thinking-mode disabled \
  > backend.log 2>&1 < /dev/null &
echo $! > backend.pid
DYN_SYSTEM_PORT=8082 DYN_REQUEST_TRACE_FILE_PATH=/tmp/reedcode-dynamo/frontend-trace.jsonl \
  nohup python3 -m dynamo.frontend --discovery-backend file \
  --router-mode kv --http-port 8000 > frontend.log 2>&1 < /dev/null &
echo $! > frontend.pid
