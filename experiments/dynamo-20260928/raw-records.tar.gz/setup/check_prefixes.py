import asyncio
import json
from pathlib import Path
from uuid import uuid4
import httpx
from openai import AsyncOpenAI
from chat_stream import stream_completion

ROOT = Path('runs/dynamo-gpu-20260928/prefix-check')
ROOT.mkdir(exist_ok=True)

async def main():
    async with AsyncOpenAI(base_url='http://127.0.0.1:18000/v1', api_key='unused', max_retries=0, timeout=90) as client, httpx.AsyncClient() as http:
        for case in ('text', 'tool'):
            for condition in ('off', 'on'):
                session = f'prefix-check-{case}-{condition}-{uuid4().hex}'
                tools = [{'type': 'function', 'function': {'name': 'record_value', 'description': 'Record a short string.', 'parameters': {'type': 'object', 'properties': {'value': {'type': 'string'}}, 'required': ['value']}}}]
                messages = [{'role': 'system', 'content': f'Run identifier: {uuid4().hex}. Follow the user instruction.'}, {'role': 'user', 'content': 'Call record_value exactly once with value ready. Do not answer in prose.' if case == 'tool' else 'Reply with exactly ready.'}]
                rows = []
                for turn in range(2):
                    before = await http.get('http://127.0.0.1:18081/metrics')
                    (ROOT / f'{case}-{condition}-{turn}-before.prom').write_text(before.text)
                    request = dict(model='Qwen/Qwen3-8B', messages=messages, temperature=0, max_completion_tokens=128)
                    if case == 'tool':
                        request.update(tools=tools, tool_choice='auto')
                    response, timing = await stream_completion(client, **request, extra_headers={'X-Dynamo-Session-ID': session}, extra_body={'nvext': {'agent_hints': {'speculative_prefill': condition == 'on'}}})
                    rows.append({'session_id': session, 'request': json.loads(json.dumps(request)), 'response': response.model_dump(), 'timing': timing})
                    await asyncio.sleep(2)
                    after = await http.get('http://127.0.0.1:18081/metrics')
                    (ROOT / f'{case}-{condition}-{turn}-after.prom').write_text(after.text)
                    choice = response.choices[0]
                    print(case, condition, turn, choice.finish_reason, response.usage, flush=True)
                    (ROOT / f'{case}-{condition}.json').write_text(json.dumps(rows, indent=2))
                    if turn == 0:
                        messages.append(choice.message.model_dump(exclude_none=True))
                        if case == 'tool':
                            if not choice.message.tool_calls:
                                raise RuntimeError('Expected a tool call')
                            for call in choice.message.tool_calls:
                                messages.append({'role': 'tool', 'tool_call_id': call.id, 'content': 'Recorded successfully. Now reply with exactly done.'})
                        else:
                            messages.append({'role':'user','content':'Now reply with exactly done.'})

asyncio.run(main())
