#!/usr/bin/env bash
set -euo pipefail
cd /tmp/reedcode-dynamo
kill "$(cat frontend.pid)"
for i in $(seq 1 30); do
  if ! kill -0 "$(cat frontend.pid)" 2>/dev/null; then break; fi
  sleep 1
done
cp frontend.log frontend-before-prefix.log
cp frontend-trace.jsonl frontend-trace-before-prefix.jsonl
export DYN_REQUEST_TRACE=1 DYN_REQUEST_TRACE_SINKS=file DYN_REQUEST_TRACE_FILE_FORMAT=jsonl
export DYN_REQUEST_TRACE_RECORDS=request_end,request_payload
export DYN_LOGGING_CONSOLE_FORMAT=jsonl DYN_EVENT_PLANE=zmq
export DYN_LOG='info,dynamo_llm::kv_router=debug'
DYN_SYSTEM_PORT=8082 DYN_REQUEST_TRACE_FILE_PATH=/tmp/reedcode-dynamo/frontend-trace.jsonl \
  nohup python3 -m dynamo.frontend --discovery-backend file \
  --router-mode kv --http-port 8000 > frontend.log 2>&1 < /dev/null &
echo $! > frontend.pid
